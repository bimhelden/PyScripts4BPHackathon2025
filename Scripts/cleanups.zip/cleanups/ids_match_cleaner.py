#!/usr/bin/env python3
"""
IDS Match Cleaner - Complete Removal
====================================

Entfernt das IDS Match Panel komplett und sauber.
Nach der Ausführung ist alles bereit für eine Neuinstallation.
"""

import bpy


def clean_ids_match():
    """Entfernt IDS Match Panel komplett."""
    print("🧹 Cleaning IDS Match Panel...")
    
    # Remove all IDS Match properties
    properties = [
        'simple_file1_loaded',
        'simple_file1_name', 
        'simple_file1_path',
        'simple_file2_loaded',
        'simple_file2_name',
        'simple_file2_path',
        'simple_tree_nodes',
        'simple_selected_index',
        'simple_show_tree'
    ]
    
    prop_count = 0
    for prop in properties:
        if hasattr(bpy.types.Scene, prop):
            try:
                delattr(bpy.types.Scene, prop)
                print(f"  ✓ Removed property: {prop}")
                prop_count += 1
            except Exception as e:
                print(f"  ✗ Failed to remove {prop}: {e}")
    
    # Remove all IDS Match classes
    classes = [
        "SIMPLE_PT_ids_panel",
        "SIMPLE_OT_show_tree", 
        "SIMPLE_OT_select_node",
        "SIMPLE_OT_load_file2",
        "SIMPLE_OT_load_file1",
        "SimpleTreeNode"
    ]
    
    class_count = 0
    for class_name in classes:
        if hasattr(bpy.types, class_name):
            try:
                cls = getattr(bpy.types, class_name)
                bpy.utils.unregister_class(cls)
                print(f"  ✓ Unregistered class: {class_name}")
                class_count += 1
            except Exception as e:
                print(f"  ✗ Failed to unregister {class_name}: {e}")
    
    # Verify cleanup
    panel_exists = hasattr(bpy.types, 'SIMPLE_PT_ids_panel')
    props_exist = hasattr(bpy.types.Scene, 'simple_file1_loaded')
    
    print("=" * 50)
    print("📊 Cleanup Summary:")
    print(f"  Properties removed: {prop_count}")
    print(f"  Classes removed: {class_count}")
    
    if not panel_exists and not props_exist:
        print("✅ IDS Match completely removed!")
        print("✅ Ready for fresh installation!")
        print("✅ Next install will show only Load IDS Files panel")
    else:
        print("⚠️ Some components may still exist")
    
    print("=" * 50)


def quick_check():
    """Schneller Status-Check."""
    panel = hasattr(bpy.types, 'SIMPLE_PT_ids_panel')
    props = hasattr(bpy.types.Scene, 'simple_file1_loaded')
    
    print("🔍 IDS Match Status:")
    print(f"  Panel: {'✅ Found' if panel else '❌ Clean'}")
    print(f"  Properties: {'✅ Found' if props else '❌ Clean'}")
    
    if not panel and not props:
        print("✅ System is clean!")
    else:
        print("⚠️ Run clean_ids_match() to remove")


# Auto-execute cleanup
if __name__ == "__main__":
    clean_ids_match()


# Available functions:
# clean_ids_match()  # Complete removal
# quick_check()      # Status check only