#!/usr/bin/env python3
"""
Remove Debug Panel Script
=========================

Entfernt das Debug Panel komplett und sauber.
"""

import bpy

def remove_debug_panel():
    """Entfernt das Debug Panel vollständig."""
    print("=" * 50)
    print("🗑️ REMOVING DEBUG PANEL")
    print("=" * 50)
    
    # 1. Properties entfernen
    debug_properties = ['debug_nodes']
    
    print("🗑️ Removing Properties...")
    for prop_name in debug_properties:
        if hasattr(bpy.types.Scene, prop_name):
            try:
                delattr(bpy.types.Scene, prop_name)
                print(f"   ✅ Removed property: {prop_name}")
            except Exception as e:
                print(f"   ⚠️ Failed to remove {prop_name}: {e}")
        else:
            print(f"   ⭕ Property not found: {prop_name}")
    
    # 2. Classes entfernen
    debug_classes = [
        'SimpleNode',
        'DEBUG_OT_find_parents',
        'DEBUG_OT_create_test_nodes', 
        'DEBUG_PT_standalone'
    ]
    
    print("🗑️ Removing Classes...")
    for class_name in debug_classes:
        if hasattr(bpy.types, class_name):
            try:
                cls = getattr(bpy.types, class_name)
                bpy.utils.unregister_class(cls)
                print(f"   ✅ Unregistered class: {class_name}")
            except Exception as e:
                print(f"   ⚠️ Failed to unregister {class_name}: {e}")
        else:
            print(f"   ⭕ Class not found: {class_name}")
    
    # 3. Force cleanup Scene attributes
    print("🧹 Force removing Scene attributes...")
    scene = bpy.context.scene
    for attr_name in dir(scene):
        if 'debug' in attr_name.lower():
            try:
                delattr(scene, attr_name)
                print(f"   ✅ Force removed scene attribute: {attr_name}")
            except:
                pass
    
    # 4. Status Check
    print("📊 Final Status Check...")
    
    # Check Properties
    remaining_props = []
    for prop in debug_properties:
        if hasattr(bpy.types.Scene, prop):
            remaining_props.append(prop)
    
    # Check Classes  
    remaining_classes = []
    for cls_name in debug_classes:
        if hasattr(bpy.types, cls_name):
            remaining_classes.append(cls_name)
    
    if not remaining_props and not remaining_classes:
        print("✅ DEBUG PANEL REMOVAL SUCCESSFUL!")
        print("   All debug components removed.")
    else:
        print("⚠️ Some debug components still remain:")
        if remaining_props:
            print(f"   Properties: {remaining_props}")
        if remaining_classes:
            print(f"   Classes: {remaining_classes}")
    
    print("=" * 50)
    print("✅ Debug panel removal complete.")
    print("   You can now register the IDS Match Panel.")
    print("=" * 50)

def check_debug_status():
    """Überprüft ob noch Debug Komponenten vorhanden sind."""
    print("=" * 40)
    print("📊 DEBUG STATUS CHECK")
    print("=" * 40)
    
    # Check Scene Properties
    debug_attrs = [attr for attr in dir(bpy.context.scene) 
                  if 'debug' in attr.lower()]
    
    print(f"Scene attributes with 'debug': {len(debug_attrs)}")
    for attr in debug_attrs:
        print(f"  - {attr}")
    
    # Check registered classes
    debug_classes = [cls.__name__ for cls in bpy.types.__dict__.values() 
                    if hasattr(cls, '__name__') and 'DEBUG' in cls.__name__]
    
    print(f"DEBUG classes registered: {len(debug_classes)}")
    for cls in debug_classes:
        print(f"  - {cls}")
    
    # Check if debug panel still visible
    panels_in_scene = [cls.__name__ for cls in bpy.types.__dict__.values() 
                      if hasattr(cls, '__name__') and 
                      hasattr(cls, 'bl_space_type') and
                      hasattr(cls, 'bl_context') and
                      cls.bl_space_type == 'PROPERTIES' and
                      cls.bl_context == 'scene']
    
    debug_panels = [p for p in panels_in_scene if 'debug' in p.lower()]
    
    print(f"Debug panels in scene context: {len(debug_panels)}")
    for panel in debug_panels:
        print(f"  - {panel}")
    
    if not debug_attrs and not debug_classes and not debug_panels:
        print("✅ NO DEBUG COMPONENTS FOUND - CLEAN!")
    else:
        print("⚠️ Some debug components still present")
    
    print("=" * 40)

if __name__ == "__main__":
    # Removal ausführen
    remove_debug_panel()
    check_debug_status()

# Commands:
# remove_debug_panel()    # Remove debug panel
# check_debug_status()    # Check if clean