#!/usr/bin/env python3
"""
Remove IDS Match Panel Script
============================

Entfernt das alte IDS Match Panel komplett und sauber.
"""

import bpy

def remove_ids_match_panel():
    """Entfernt das IDS Match Panel vollständig."""
    print("=" * 60)
    print("🗑️ REMOVING IDS MATCH PANEL")
    print("=" * 60)
    
    # 1. Properties entfernen
    match_properties = [
        'ids_file1_loaded',
        'ids_file1_name', 
        'ids_file2_loaded',
        'ids_file2_name',
        'ids_tree_nodes'
    ]
    
    print("🗑️ Removing Properties...")
    for prop_name in match_properties:
        if hasattr(bpy.types.Scene, prop_name):
            try:
                delattr(bpy.types.Scene, prop_name)
                print(f"   ✅ Removed property: {prop_name}")
            except Exception as e:
                print(f"   ⚠️ Failed to remove {prop_name}: {e}")
        else:
            print(f"   ⭕ Property not found: {prop_name}")
    
    # 2. Classes entfernen
    match_classes = [
        'IDS_TreeNode',
        'BIM_OT_load_ids_file_1',
        'BIM_OT_load_ids_file_2', 
        'BIM_PT_ids_match'
    ]
    
    print("🗑️ Removing Classes...")
    for class_name in match_classes:
        if hasattr(bpy.types, class_name):
            try:
                cls = getattr(bpy.types, class_name)
                bpy.utils.unregister_class(cls)
                print(f"   ✅ Unregistered class: {class_name}")
            except Exception as e:
                print(f"   ⚠️ Failed to unregister {class_name}: {e}")
        else:
            print(f"   ⭕ Class not found: {class_name}")
    
    # 3. Force cleanup Scene attributes
    print("🧹 Force removing Scene attributes...")
    scene = bpy.context.scene
    for attr_name in dir(scene):
        if any(keyword in attr_name for keyword in ['ids_file', 'ids_tree']):
            try:
                delattr(scene, attr_name)
                print(f"   ✅ Force removed scene attribute: {attr_name}")
            except:
                pass
    
    # 4. Status Check
    print("📊 Final Status Check...")
    
    # Check Properties
    remaining_props = []
    for prop in match_properties:
        if hasattr(bpy.types.Scene, prop):
            remaining_props.append(prop)
    
    # Check Classes  
    remaining_classes = []
    for cls_name in match_classes:
        if hasattr(bpy.types, cls_name):
            remaining_classes.append(cls_name)
    
    if not remaining_props and not remaining_classes:
        print("✅ IDS MATCH PANEL REMOVAL SUCCESSFUL!")
        print("   All IDS match components removed.")
    else:
        print("⚠️ Some IDS match components still remain:")
        if remaining_props:
            print(f"   Properties: {remaining_props}")
        if remaining_classes:
            print(f"   Classes: {remaining_classes}")
    
    print("=" * 60)
    print("✅ IDS Match Panel removal complete.")
    print("   You can now register the updated JSON-based panel.")
    print("=" * 60)

def check_ids_match_status():
    """Überprüft ob noch IDS Match Komponenten vorhanden sind."""
    print("=" * 50)
    print("📊 IDS MATCH STATUS CHECK")
    print("=" * 50)
    
    # Check Scene Properties
    ids_attrs = [attr for attr in dir(bpy.context.scene) 
                if any(keyword in attr for keyword in ['ids_file', 'ids_tree', 'ids_match'])]
    
    print(f"Scene attributes with IDS keywords: {len(ids_attrs)}")
    for attr in ids_attrs:
        print(f"  - {attr}")
    
    # Check registered classes
    ids_classes = [cls.__name__ for cls in bpy.types.__dict__.values() 
                  if hasattr(cls, '__name__') and 
                  any(keyword in cls.__name__ for keyword in ['IDS_', 'BIM_OT_load_ids', 'BIM_PT_ids'])]
    
    print(f"IDS classes registered: {len(ids_classes)}")
    for cls in ids_classes:
        print(f"  - {cls}")
    
    # Check panels in collaboration
    collab_panels = [cls.__name__ for cls in bpy.types.__dict__.values() 
                    if hasattr(cls, '__name__') and 
                    hasattr(cls, 'bl_parent_id') and
                    hasattr(cls.bl_parent_id, '__str__') and
                    'collaboration' in str(cls.bl_parent_id).lower()]
    
    print(f"Panels under collaboration: {len(collab_panels)}")
    for panel in collab_panels:
        print(f"  - {panel}")
    
    if not ids_attrs and not ids_classes:
        print("✅ NO IDS MATCH COMPONENTS FOUND - CLEAN!")
    else:
        print("⚠️ Some IDS match components still present")
    
    print("=" * 50)

def force_clean_all_ids():
    """Nuclear option - entfernt ALLES was mit IDS zu tun hat."""
    print("=" * 60)
    print("☢️ NUCLEAR CLEANUP - ALL IDS COMPONENTS")
    print("=" * 60)
    
    # Alle IDS-verwandten Properties
    scene = bpy.context.scene
    ids_attrs = [attr for attr in dir(scene) 
                if any(keyword in attr.lower() for keyword in ['ids', 'tree', 'node'])]
    
    print(f"Force removing {len(ids_attrs)} scene attributes...")
    for attr in ids_attrs:
        try:
            delattr(scene, attr)
            print(f"   ✅ Removed: {attr}")
        except:
            pass
    
    # Alle IDS-verwandten Classes
    ids_class_names = [cls.__name__ for cls in bpy.types.__dict__.values() 
                      if hasattr(cls, '__name__') and 
                      any(keyword in cls.__name__ for keyword in ['IDS', 'ids', 'TreeNode', 'load_ids'])]
    
    print(f"Force unregistering {len(ids_class_names)} classes...")
    for cls_name in ids_class_names:
        if hasattr(bpy.types, cls_name):
            try:
                cls = getattr(bpy.types, cls_name)
                bpy.utils.unregister_class(cls)
                print(f"   ✅ Unregistered: {cls_name}")
            except:
                pass
    
    print("☢️ Nuclear cleanup completed!")
    print("=" * 60)

if __name__ == "__main__":
    # Normal removal
    remove_ids_match_panel()
    check_ids_match_status()

# Commands:
# remove_ids_match_panel()    # Normal removal
# check_ids_match_status()    # Check status
# force_clean_all_ids()       # Nuclear option