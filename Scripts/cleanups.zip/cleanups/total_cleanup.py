#!/usr/bin/env python3
"""
Total Cleanup - All IDS Panels
==============================

Entfernt ALLE IDS-related Panels und Components komplett.
"""

import bpy

def total_cleanup():
    """Entfernt ALLES was mit IDS, DEBUG, SIMPLE zu tun hat"""
    print("=" * 60)
    print("🧹 TOTAL CLEANUP - ALL IDS PANELS")
    print("=" * 60)
    
    # 1. ALLE IDS Properties entfernen
    all_properties = [
        # Original IDS Match
        'ids_file1_loaded', 'ids_file1_name', 'ids_file2_loaded', 'ids_file2_name', 
        'ids_file2_path', 'ids_tree_nodes', 'ids_selected_node_index',
        'ids_show_analysis', 'ids_match_completed', 'ids_match_found_class', 
        'ids_match_property_groups', 'ids_match_selected_group_index',
        
        # Simple IDS
        'simple_file1_loaded', 'simple_file2_loaded', 'simple_file2_path',
        'simple_selected_index', 'simple_tree_nodes', 'simple_match_completed',
        'simple_found_class', 'simple_property_groups',
        
        # Debug
        'debug_nodes'
    ]
    
    print("🗑️ Removing ALL Properties...")
    for prop in all_properties:
        if hasattr(bpy.types.Scene, prop):
            try:
                delattr(bpy.types.Scene, prop)
                print(f"   ✅ Removed: {prop}")
            except Exception as e:
                print(f"   ⚠️ Failed: {prop} - {e}")
    
    # 2. ALLE IDS Classes entfernen
    all_classes = [
        # Original IDS Match Classes
        'IDS_PropertyGroup', 'IDS_TreeNode', 'BIM_OT_match_ids_element',
        'BIM_OT_analyze_ids', 'BIM_OT_select_tree_node', 'BIM_OT_toggle_tree_node',
        'BIM_OT_load_ids_file_1', 'BIM_OT_load_ids_file_2', 'BIM_OT_reset_ids_files',
        'BIM_PT_ids_match', 'BIM_OT_select_property_group',
        
        # Simple IDS Classes
        'SimplePropertyGroup', 'SimpleTreeNode', 'SIMPLE_OT_match_ids',
        'SIMPLE_PT_ids_match',
        
        # Debug Classes
        'DEBUG_PT_ids_status', 'SimpleNode', 'DEBUG_OT_find_parents',
        'DEBUG_OT_create_test_nodes', 'DEBUG_PT_standalone'
    ]
    
    print("🗑️ Removing ALL Classes...")
    for cls_name in all_classes:
        if hasattr(bpy.types, cls_name):
            try:
                cls = getattr(bpy.types, cls_name)
                bpy.utils.unregister_class(cls)
                print(f"   ✅ Unregistered: {cls_name}")
            except Exception as e:
                print(f"   ⚠️ Failed: {cls_name} - {e}")
    
    # 3. Force remove Scene attributes
    print("🧹 Force removing Scene attributes...")
    scene = bpy.context.scene
    attrs_to_remove = []
    
    for attr_name in dir(scene):
        if any(keyword in attr_name.lower() for keyword in ['ids_', 'simple_', 'debug_']):
            attrs_to_remove.append(attr_name)
    
    for attr in attrs_to_remove:
        try:
            delattr(scene, attr)
            print(f"   ✅ Force removed: {attr}")
        except:
            pass
    
    # 4. Status Check
    print("📊 Final Status Check...")
    
    remaining_props = []
    for prop in all_properties:
        if hasattr(bpy.types.Scene, prop):
            remaining_props.append(prop)
    
    remaining_classes = []
    for cls_name in all_classes:
        if hasattr(bpy.types, cls_name):
            remaining_classes.append(cls_name)
    
    if not remaining_props and not remaining_classes:
        print("✅ TOTAL CLEANUP SUCCESSFUL!")
        print("   All IDS panels and components removed.")
    else:
        print("⚠️ Some components still remain:")
        if remaining_props:
            print(f"   Properties: {remaining_props}")
        if remaining_classes:
            print(f"   Classes: {remaining_classes}")
    
    print("=" * 60)
    print("✅ Total cleanup completed!")
    print("   You can now register fresh panels.")
    print("=" * 60)

def check_all_panels():
    """Überprüft welche Panels noch existieren"""
    print("=" * 50)
    print("📊 ALL PANELS CHECK")
    print("=" * 50)
    
    # Check for IDS-related panels
    ids_panels = [cls.__name__ for cls in bpy.types.__dict__.values() 
                 if hasattr(cls, '__name__') and 
                 any(keyword in cls.__name__.lower() for keyword in ['ids', 'simple', 'debug'])]
    
    print(f"IDS-related panels found: {len(ids_panels)}")
    for panel in ids_panels:
        print(f"  - {panel}")
    
    # Check Scene properties
    scene_attrs = [attr for attr in dir(bpy.context.scene) 
                  if any(keyword in attr.lower() for keyword in ['ids', 'simple', 'debug'])]
    
    print(f"IDS-related scene properties: {len(scene_attrs)}")
    for attr in scene_attrs:
        print(f"  - {attr}")
    
    if not ids_panels and not scene_attrs:
        print("✅ COMPLETELY CLEAN - No IDS components found!")
    else:
        print("⚠️ Some IDS components still present")
    
    print("=" * 50)

if __name__ == "__main__":
    total_cleanup()
    check_all_panels()

# Commands:
# total_cleanup()      # Complete removal
# check_all_panels()   # Check what's left