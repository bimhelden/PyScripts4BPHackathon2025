#!/usr/bin/env python3
"""
Remove Old and Register New IDS Match Panel
===========================================

Komplett entfernen und neu registrieren
"""

import bpy

def complete_cleanup():
    """Entfernt ALLES IDS Match related"""
    print("🧹 Complete IDS Match Cleanup...")
    
    # Remove all IDS properties
    ids_properties = [
        'ids_file1_loaded', 'ids_file1_name', 'ids_file2_loaded', 'ids_file2_name', 
        'ids_file2_path', 'ids_tree_nodes', 'ids_selected_node_index',
        'ids_show_analysis', 'ids_match_completed', 'ids_match_found_class', 
        'ids_match_property_groups'
    ]
    
    for prop in ids_properties:
        if hasattr(bpy.types.Scene, prop):
            try:
                delattr(bpy.types.Scene, prop)
                print(f"   ✅ Removed property: {prop}")
            except:
                pass
    
    # Remove all IDS classes
    ids_classes = [
        'IDS_PropertyGroup', 'IDS_TreeNode', 'BIM_OT_match_ids_element',
        'BIM_OT_analyze_ids', 'BIM_OT_select_tree_node', 'BIM_OT_toggle_tree_node',
        'BIM_OT_load_ids_file_1', 'BIM_OT_load_ids_file_2', 'BIM_OT_reset_ids_files',
        'BIM_PT_ids_match'
    ]
    
    for cls_name in ids_classes:
        if hasattr(bpy.types, cls_name):
            try:
                cls = getattr(bpy.types, cls_name)
                bpy.utils.unregister_class(cls)
                print(f"   ✅ Unregistered class: {cls_name}")
            except:
                pass
    
    # Force remove scene attributes
    scene = bpy.context.scene
    for attr in dir(scene):
        if 'ids_' in attr.lower():
            try:
                delattr(scene, attr)
                print(f"   ✅ Force removed: {attr}")
            except:
                pass
    
    print("✅ Complete cleanup done!")

if __name__ == "__main__":
    complete_cleanup()

# Verwendung:
# complete_cleanup()  # Erst alles entfernen
# Dann das neue Panel Script ausführen