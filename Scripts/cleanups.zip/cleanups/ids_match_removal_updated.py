#!/usr/bin/env python3
"""
IDS Match Panel - Complete Removal Code (Updated)
=================================================

Vollständige Entfernung aller IDS Match Panel Komponenten inklusive 
dem BIM_PT_collaboration Parent Panel.

Usage:
    force_remove_ids_match()
"""

import bpy


def remove_ids_match_properties():
    """Entfernt alle IDS Match Scene Properties."""
    print("🧹 Removing IDS Match properties...")
    
    # Liste aller IDS Match Properties
    props = [
        # File 1 properties
        'ids_match_file1_loaded',
        'ids_match_file1_name', 
        'ids_match_file1_path',
        'ids_match_file1_entities',
        
        # File 2 properties
        'ids_match_file2_loaded',
        'ids_match_file2_name',
        'ids_match_file2_path', 
        'ids_match_file2_entities',
        
        # Tree properties
        'ids_match_tree_nodes',
        'ids_match_selected_index',
        'ids_match_show_tree',
        'ids_match_active_file',
        
        # Legacy properties (falls vorhanden)
        'simple_file1_loaded',
        'simple_file1_name',
        'simple_file1_path',
        'simple_file2_loaded', 
        'simple_file2_name',
        'simple_file2_path',
        'simple_tree_nodes',
        'simple_selected_index',
        'simple_show_tree'
    ]
    
    removed_count = 0
    for prop in props:
        if hasattr(bpy.types.Scene, prop):
            try:
                delattr(bpy.types.Scene, prop)
                print(f"  ✓ Removed property: {prop}")
                removed_count += 1
            except Exception as e:
                print(f"  ✗ Failed to remove property {prop}: {e}")
    
    print(f"✅ Removed {removed_count} properties")
    return removed_count


def remove_ids_match_classes():
    """Entfernt alle IDS Match Classes inklusive Parent Panel."""
    print("🧹 Removing IDS Match classes...")
    
    # Liste aller IDS Match Classes (in umgekehrter Reihenfolge)
    class_names = [
        # Child Panels zuerst
        "BIM_PT_ids_match",
        
        # Operators  
        "BIM_OT_select_tree_node",
        "BIM_OT_show_ids_tree",
        "BIM_OT_load_ids_file2", 
        "BIM_OT_load_ids_file1",
        
        # Parent Panel zuletzt
        "BIM_PT_collaboration",
        
        # Property Groups zuletzt
        "IdsMatchTreeNode",
        
        # Legacy Classes (falls vorhanden)
        "SIMPLE_PT_ids_panel",
        "SIMPLE_OT_select_node",
        "SIMPLE_OT_show_tree",
        "SIMPLE_OT_load_file2",
        "SIMPLE_OT_load_file1",
        "SimpleTreeNode"
    ]
    
    removed_count = 0
    for class_name in class_names:
        if hasattr(bpy.types, class_name):
            try:
                cls = getattr(bpy.types, class_name)
                bpy.utils.unregister_class(cls)
                print(f"  ✓ Unregistered class: {class_name}")
                removed_count += 1
            except Exception as e:
                print(f"  ✗ Failed to unregister class {class_name}: {e}")
    
    print(f"✅ Unregistered {removed_count} classes")
    return removed_count


def check_ids_match_status():
    """Überprüft den aktuellen Status von IDS Match Komponenten."""
    print("📋 Checking IDS Match status...")
    
    # Check Properties
    property_names = [
        'ids_match_file1_loaded', 'ids_match_file1_name', 'ids_match_file1_path',
        'ids_match_file2_loaded', 'ids_match_file2_name', 'ids_match_file2_path', 
        'ids_match_tree_nodes', 'ids_match_selected_index', 'ids_match_show_tree',
        'ids_match_active_file', 'ids_match_file1_entities', 'ids_match_file2_entities',
        'simple_file1_loaded', 'simple_file1_name', 'simple_tree_nodes'
    ]
    
    found_properties = []
    for prop in property_names:
        if hasattr(bpy.types.Scene, prop):
            found_properties.append(prop)
    
    # Check Classes
    class_names = [
        "BIM_PT_collaboration", "BIM_PT_ids_match", 
        "BIM_OT_load_ids_file1", "BIM_OT_load_ids_file2",
        "BIM_OT_show_ids_tree", "BIM_OT_select_tree_node", 
        "IdsMatchTreeNode",
        "SIMPLE_PT_ids_panel", "SIMPLE_OT_load_file1", "SimpleTreeNode"
    ]
    
    found_classes = []
    for class_name in class_names:
        if hasattr(bpy.types, class_name):
            found_classes.append(class_name)
    
    # Report Status
    if not found_properties and not found_classes:
        print("✅ IDS Match Panel completely removed!")
        return True
    else:
        print("⚠️ IDS Match components still found:")
        if found_properties:
            print(f"  Properties ({len(found_properties)}): {found_properties}")
        if found_classes:
            print(f"  Classes ({len(found_classes)}): {found_classes}")
        return False


def force_remove_ids_match():
    """Forciert die komplette Entfernung aller IDS Match Komponenten."""
    print("🔥 FORCE REMOVING all IDS Match components...")
    print("=" * 50)
    
    # Schritt 1: Properties entfernen
    prop_count = remove_ids_match_properties()
    
    # Schritt 2: Classes entfernen  
    class_count = remove_ids_match_classes()
    
    # Schritt 3: Status überprüfen
    is_clean = check_ids_match_status()
    
    print("=" * 50)
    print(f"📊 Removal Summary:")
    print(f"  Properties removed: {prop_count}")
    print(f"  Classes removed: {class_count}")
    print(f"  Status: {'✅ COMPLETELY CLEAN' if is_clean else '⚠️ PARTIALLY REMOVED'}")
    print("=" * 50)
    
    return is_clean


def quick_clean():
    """Schnelle Bereinigung - Alias für force_remove_ids_match."""
    return force_remove_ids_match()


# Direkte Ausführung
if __name__ == "__main__":
    force_remove_ids_match()


# === USAGE ===
"""
# Komplette Entfernung (empfohlen):
force_remove_ids_match()

# Schnelle Bereinigung:
quick_clean()

# Status checken:
check_ids_match_status()

# Nur Properties entfernen:
remove_ids_match_properties()

# Nur Classes entfernen: 
remove_ids_match_classes()
"""