#!/usr/bin/env python3
"""
Complete Cleanup - Including Scene Data
=======================================

Entfernt IDS Match Panel UND alle gespeicherten Szenen-Daten.
Das war das Problem - die Properties bleiben in der .blend Datei!
"""

import bpy


def clean_ids_match_complete():
    """Komplette Entfernung inkl. Szenen-Daten."""
    print("🔥 COMPLETE IDS MATCH CLEANUP")
    print("=" * 50)
    
    # 1. Remove Properties from Scene Definition
    properties = [
        'simple_file1_loaded',
        'simple_file1_name', 
        'simple_file1_path',
        'simple_file2_loaded',
        'simple_file2_name',
        'simple_file2_path',
        'simple_tree_nodes',
        'simple_selected_index',
        'simple_show_tree'
    ]
    
    prop_count = 0
    for prop in properties:
        if hasattr(bpy.types.Scene, prop):
            try:
                delattr(bpy.types.Scene, prop)
                print(f"  ✓ Removed property definition: {prop}")
                prop_count += 1
            except Exception as e:
                print(f"  ✗ Failed to remove {prop}: {e}")
    
    # 2. Remove Classes
    classes = [
        "SIMPLE_PT_ids_panel",
        "SIMPLE_OT_analyze_ids",
        "SIMPLE_OT_select_node", 
        "SIMPLE_OT_load_file2",
        "SIMPLE_OT_load_file1",
        "SimpleTreeNode"
    ]
    
    class_count = 0
    for class_name in classes:
        if hasattr(bpy.types, class_name):
            try:
                cls = getattr(bpy.types, class_name)
                bpy.utils.unregister_class(cls)
                print(f"  ✓ Unregistered class: {class_name}")
                class_count += 1
            except Exception as e:
                print(f"  ✗ Failed to unregister {class_name}: {e}")
    
    # 3. WICHTIG: Clear actual scene data!
    scene = bpy.context.scene
    scene_data_cleared = 0
    
    # Clear tree nodes if they exist
    if hasattr(scene, 'simple_tree_nodes'):
        scene.simple_tree_nodes.clear()
        print("  ✓ Cleared tree_nodes from current scene")
        scene_data_cleared += 1
    
    # Reset all simple_ attributes in current scene
    simple_attrs = [attr for attr in dir(scene) if attr.startswith('simple_')]
    for attr in simple_attrs:
        try:
            if attr == 'simple_tree_nodes':
                getattr(scene, attr).clear()
            elif attr == 'simple_show_tree':
                setattr(scene, attr, False)
            elif attr == 'simple_selected_index':
                setattr(scene, attr, -1)
            elif attr.endswith('_loaded'):
                setattr(scene, attr, False)
            else:
                setattr(scene, attr, "")
            print(f"  ✓ Reset scene attribute: {attr}")
            scene_data_cleared += 1
        except Exception as e:
            print(f"  ✗ Failed to reset {attr}: {e}")
    
    # 4. Clear from ALL scenes in the file
    all_scenes_cleared = 0
    for scene_obj in bpy.data.scenes:
        simple_attrs = [attr for attr in dir(scene_obj) if attr.startswith('simple_')]
        for attr in simple_attrs:
            try:
                if attr == 'simple_tree_nodes':
                    getattr(scene_obj, attr).clear()
                elif attr == 'simple_show_tree':
                    setattr(scene_obj, attr, False)
                elif attr == 'simple_selected_index':
                    setattr(scene_obj, attr, -1)
                elif attr.endswith('_loaded'):
                    setattr(scene_obj, attr, False)
                else:
                    setattr(scene_obj, attr, "")
                all_scenes_cleared += 1
            except:
                pass
    
    # 5. Force UI update
    try:
        for area in bpy.context.screen.areas:
            if area.type == 'PROPERTIES':
                area.tag_redraw()
        print("  ✓ Forced UI refresh")
    except:
        pass
    
    # 6. Verify cleanup
    panel_exists = hasattr(bpy.types, 'SIMPLE_PT_ids_panel')
    props_exist = hasattr(bpy.types.Scene, 'simple_file1_loaded')
    scene_data_exists = hasattr(bpy.context.scene, 'simple_tree_nodes') and len(bpy.context.scene.simple_tree_nodes) > 0
    
    print("=" * 50)
    print("📊 CLEANUP SUMMARY:")
    print(f"  Property definitions removed: {prop_count}")
    print(f"  Classes removed: {class_count}")
    print(f"  Current scene data cleared: {scene_data_cleared}")
    print(f"  All scenes data cleared: {all_scenes_cleared}")
    print()
    print("🔍 VERIFICATION:")
    print(f"  Panel exists: {'❌ Still there' if panel_exists else '✅ Removed'}")
    print(f"  Property definitions exist: {'❌ Still there' if props_exist else '✅ Removed'}")
    print(f"  Scene tree data exists: {'❌ Still there' if scene_data_exists else '✅ Cleared'}")
    
    success = not panel_exists and not props_exist and not scene_data_exists
    
    if success:
        print("✅ COMPLETE SUCCESS - IDS Match fully removed!")
        print("✅ Save your .blend file to make permanent!")
        print("✅ Next installation will be completely clean!")
    else:
        print("⚠️ Some data may still exist - check above details")
    
    print("=" * 50)
    print("💡 IMPORTANT: Save your .blend file now to make the cleanup permanent!")
    
    return success


def quick_scene_check():
    """Prüft was in der aktuellen Szene noch da ist."""
    scene = bpy.context.scene
    simple_attrs = [attr for attr in dir(scene) if attr.startswith('simple_')]
    
    print("🔍 Current Scene IDS Data:")
    if simple_attrs:
        for attr in simple_attrs:
            try:
                value = getattr(scene, attr)
                if attr == 'simple_tree_nodes':
                    print(f"  {attr}: {len(value)} nodes")
                else:
                    print(f"  {attr}: {value}")
            except:
                print(f"  {attr}: <error reading>")
    else:
        print("  ✅ No IDS data found in current scene")


# Auto-execute
if __name__ == "__main__":
    clean_ids_match_complete()


# Available functions:
# clean_ids_match_complete()  # Complete removal including scene data
# quick_scene_check()         # Check what's still in current scene