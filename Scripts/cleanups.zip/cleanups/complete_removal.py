#!/usr/bin/env python3
"""
Complete Removal Script - All Test Panels
==========================================

Entfernt ALLE Test Panels, IDS Match Panels und Properties komplett.
Führt eine vollständige Bereinigung durch.
"""

import bpy

def force_remove_all():
    """Entfernt alle Test und IDS Match Komponenten vollständig."""
    print("=" * 60)
    print("🧹 COMPLETE REMOVAL - ALL TEST PANELS")
    print("=" * 60)
    
    # 1. ALLE Properties entfernen
    properties_to_remove = [
        # IDS Match Properties
        'ids_match_file1_loaded',
        'ids_match_file1_name', 
        'ids_match_file2_loaded',
        'ids_match_file2_name',
        'ids_match_show_tree',
        'ids_match_tree_nodes',
        
        # Test Properties
        'test_nodes',
    ]
    
    print("🗑️ Removing Properties...")
    for prop_name in properties_to_remove:
        if hasattr(bpy.types.Scene, prop_name):
            try:
                delattr(bpy.types.Scene, prop_name)
                print(f"   ✅ Removed property: {prop_name}")
            except Exception as e:
                print(f"   ⚠️ Failed to remove {prop_name}: {e}")
        else:
            print(f"   ⭕ Property not found: {prop_name}")
    
    # 2. ALLE Klassen entfernen
    class_names = [
        # IDS Match Classes
        'IDS_Specification_Item',
        'IDS_Comparison_Result', 
        'IDS_TreeNode',
        'IDS_UL_tree_view',
        'BIM_OT_load_ids_file_1',
        'BIM_OT_load_ids_file_2',
        'BIM_OT_show_ids_tree',
        'BIM_OT_compare_ids_files',
        'BIM_OT_test_tree',
        'BIM_PT_ids_match',
        
        # Test Classes
        'SimpleNode',
        'TEST_OT_create_nodes',
        'DEBUG_OT_list_panels',
        'TEST_PT_panel',
        'TEST_PT_panel_no_parent',
    ]
    
    print("🗑️ Removing Classes...")
    for class_name in class_names:
        if hasattr(bpy.types, class_name):
            try:
                cls = getattr(bpy.types, class_name)
                bpy.utils.unregister_class(cls)
                print(f"   ✅ Unregistered class: {class_name}")
            except Exception as e:
                print(f"   ⚠️ Failed to unregister {class_name}: {e}")
        else:
            print(f"   ⭕ Class not found: {class_name}")
    
    # 3. Scene Attributes direkt entfernen (falls Properties nicht funktioniert)
    print("🧹 Force removing Scene attributes...")
    scene = bpy.context.scene
    for attr_name in dir(scene):
        if any(keyword in attr_name for keyword in ['ids_match', 'test_nodes']):
            try:
                delattr(scene, attr_name)
                print(f"   ✅ Force removed scene attribute: {attr_name}")
            except:
                pass
    
    # 4. Status Check
    print("📊 Final Status Check...")
    
    # Check Properties
    remaining_props = []
    for prop in properties_to_remove:
        if hasattr(bpy.types.Scene, prop):
            remaining_props.append(prop)
    
    # Check Classes  
    remaining_classes = []
    for cls_name in class_names:
        if hasattr(bpy.types, cls_name):
            remaining_classes.append(cls_name)
    
    if not remaining_props and not remaining_classes:
        print("✅ COMPLETE REMOVAL SUCCESSFUL!")
        print("   All test panels and IDS match components removed.")
    else:
        print("⚠️ Some components still remain:")
        if remaining_props:
            print(f"   Properties: {remaining_props}")
        if remaining_classes:
            print(f"   Classes: {remaining_classes}")
    
    print("=" * 60)
    print("✅ Removal complete. You can now register new panels.")
    print("=" * 60)

def status_check():
    """Überprüft welche Test Komponenten noch vorhanden sind."""
    print("=" * 50)
    print("📊 STATUS CHECK")
    print("=" * 50)
    
    # Check Scene Properties
    scene_attrs = [attr for attr in dir(bpy.context.scene) 
                  if any(keyword in attr for keyword in ['ids_match', 'test'])]
    
    print(f"Scene attributes with 'ids_match' or 'test': {len(scene_attrs)}")
    for attr in scene_attrs:
        print(f"  - {attr}")
    
    # Check registered classes
    test_classes = [cls.__name__ for cls in bpy.types.__dict__.values() 
                   if hasattr(cls, '__name__') and 
                   any(keyword in cls.__name__ for keyword in ['IDS', 'TEST', 'test'])]
    
    print(f"Test/IDS classes registered: {len(test_classes)}")
    for cls in test_classes:
        print(f"  - {cls}")
    
    # Check all BIM panels
    bim_panels = [cls.__name__ for cls in bpy.types.__dict__.values() 
                 if hasattr(cls, '__name__') and 'BIM_PT' in cls.__name__]
    
    print(f"All BIM panels: {len(bim_panels)}")
    for panel in sorted(bim_panels):
        print(f"  - {panel}")
    
    print("=" * 50)

if __name__ == "__main__":
    # Ausführen
    force_remove_all()
    status_check()

# Commands:
# force_remove_all()    # Complete removal
# status_check()        # Check what's still there