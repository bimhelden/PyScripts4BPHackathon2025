#!/usr/bin/env python3
"""
Bonsai-Safe Cleanup - No File Saving Required
==============================================

Cleanup für Bonsai wo .blend Dateien nicht gespeichert werden dürfen.
Setzt Properties auf "unsichtbare" Default-Werte.
"""

import bpy


def bonsai_safe_cleanup():
    """Cleanup der in Bonsai funktioniert ohne .blend zu speichern."""
    print("🔥 BONSAI-SAFE IDS MATCH CLEANUP")
    print("=" * 50)
    
    # 1. Remove Classes first
    classes = [
        "SIMPLE_PT_ids_panel",
        "SIMPLE_OT_analyze_ids", 
        "SIMPLE_OT_select_node", 
        "SIMPLE_OT_load_file2",
        "SIMPLE_OT_load_file1",
        "SimpleTreeNode"
    ]
    
    class_count = 0
    for class_name in classes:
        if hasattr(bpy.types, class_name):
            try:
                cls = getattr(bpy.types, class_name)
                bpy.utils.unregister_class(cls)
                print(f"  ✓ Unregistered: {class_name}")
                class_count += 1
            except Exception as e:
                print(f"  ✗ Failed: {class_name} - {e}")
    
    # 2. Reset Scene Data zu "unsichtbaren" Defaults
    scene = bpy.context.scene
    reset_count = 0
    
    # Reset all simple_ attributes to make them "invisible"
    try:
        if hasattr(scene, 'simple_tree_nodes'):
            scene.simple_tree_nodes.clear()
            print("  ✓ Cleared tree_nodes")
            reset_count += 1
    except:
        pass
    
    try:
        if hasattr(scene, 'simple_show_tree'):
            scene.simple_show_tree = False
            print("  ✓ Reset show_tree to False")
            reset_count += 1
    except:
        pass
    
    try:
        if hasattr(scene, 'simple_selected_index'):
            scene.simple_selected_index = -1
            print("  ✓ Reset selected_index to -1")
            reset_count += 1
    except:
        pass
    
    try:
        if hasattr(scene, 'simple_file1_loaded'):
            scene.simple_file1_loaded = False
            print("  ✓ Reset file1_loaded to False")
            reset_count += 1
    except:
        pass
    
    try:
        if hasattr(scene, 'simple_file2_loaded'):
            scene.simple_file2_loaded = False
            print("  ✓ Reset file2_loaded to False")
            reset_count += 1
    except:
        pass
    
    try:
        if hasattr(scene, 'simple_file1_name'):
            scene.simple_file1_name = ""
            print("  ✓ Reset file1_name to empty")
            reset_count += 1
    except:
        pass
    
    try:
        if hasattr(scene, 'simple_file2_name'):
            scene.simple_file2_name = ""
            print("  ✓ Reset file2_name to empty")
            reset_count += 1
    except:
        pass
    
    try:
        if hasattr(scene, 'simple_file1_path'):
            scene.simple_file1_path = ""
            print("  ✓ Reset file1_path to empty")
            reset_count += 1
    except:
        pass
    
    try:
        if hasattr(scene, 'simple_file2_path'):
            scene.simple_file2_path = ""
            print("  ✓ Reset file2_path to empty")
            reset_count += 1
    except:
        pass
    
    # 3. Remove Property Definitions (this prevents new registrations from seeing old data)
    properties = [
        'simple_file1_loaded', 'simple_file1_name', 'simple_file1_path',
        'simple_file2_loaded', 'simple_file2_name', 'simple_file2_path',
        'simple_tree_nodes', 'simple_selected_index', 'simple_show_tree'
    ]
    
    prop_count = 0
    for prop in properties:
        if hasattr(bpy.types.Scene, prop):
            try:
                delattr(bpy.types.Scene, prop)
                print(f"  ✓ Removed property: {prop}")
                prop_count += 1
            except Exception as e:
                print(f"  ✗ Failed to remove {prop}: {e}")
    
    # 4. Force UI refresh
    try:
        for area in bpy.context.screen.areas:
            if area.type == 'PROPERTIES':
                area.tag_redraw()
        print("  ✓ UI refreshed")
    except:
        pass
    
    # 5. Verification
    panel_exists = hasattr(bpy.types, 'SIMPLE_PT_ids_panel')
    props_exist = hasattr(bpy.types.Scene, 'simple_file1_loaded')
    
    print("=" * 50)
    print("📊 CLEANUP SUMMARY:")
    print(f"  Classes removed: {class_count}")
    print(f"  Scene data reset: {reset_count}")
    print(f"  Property definitions removed: {prop_count}")
    print()
    print("🔍 STATUS:")
    print(f"  Panel: {'❌ Still exists' if panel_exists else '✅ Removed'}")
    print(f"  Properties: {'❌ Still exist' if props_exist else '✅ Removed'}")
    
    success = not panel_exists and not props_exist
    
    if success:
        print("✅ CLEANUP SUCCESSFUL!")
        print("✅ Next IDS Match installation will be clean!")
        print("✅ No .blend file saving required!")
    else:
        print("⚠️ Some components may still exist")
    
    print("=" * 50)
    
    return success


def check_current_state():
    """Zeigt aktuellen Status ohne etwas zu ändern."""
    scene = bpy.context.scene
    
    print("🔍 CURRENT IDS MATCH STATE:")
    print("=" * 30)
    
    # Check classes
    panel_exists = hasattr(bpy.types, 'SIMPLE_PT_ids_panel')
    props_exist = hasattr(bpy.types.Scene, 'simple_file1_loaded')
    
    print(f"Panel class: {'✅ EXISTS' if panel_exists else '❌ MISSING'}")
    print(f"Property definitions: {'✅ EXISTS' if props_exist else '❌ MISSING'}")
    
    # Check scene data
    scene_data = []
    simple_attrs = [attr for attr in dir(scene) if attr.startswith('simple_')]
    for attr in simple_attrs:
        try:
            value = getattr(scene, attr)
            if attr == 'simple_tree_nodes':
                scene_data.append(f"{attr}: {len(value)} nodes")
            else:
                scene_data.append(f"{attr}: {value}")
        except:
            scene_data.append(f"{attr}: <error>")
    
    if scene_data:
        print("Scene data found:")
        for data in scene_data:
            print(f"  {data}")
    else:
        print("Scene data: ✅ CLEAN")
    
    print("=" * 30)


# Auto-execute
if __name__ == "__main__":
    bonsai_safe_cleanup()


# Available functions:
# bonsai_safe_cleanup()  # Safe cleanup for Bonsai
# check_current_state()  # Check current status